const express = require('express');
const cors = require('cors'); // Import cors

const app = express();
const userRoutes = require('./routes/userRoutes'); // Make sure the path to userRoutes is correct

// Use CORS middleware
app.use(cors({
  origin: 'http://localhost:5173', // Allow requests only from this origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // Specify the allowed HTTP methods
  credentials: true // Allow cookies to be sent along with requests
}));

app.use(express.json()); // For parsing application/json

app.use('/api/users', userRoutes);

const PORT = process.env.PORT || 4050;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
